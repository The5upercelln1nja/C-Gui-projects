Good day all 


I hope you find my application user friendly

For question 1 , The main classes for showing the view of the registration is known as the ConferenceView and the input dialog class is InputDialog class 

These classes have been connected via signals and slots to provide an addition of registrations at a click of a button ,the type of registration functionality has been introduced in the dialog box ,I have used the QMetaObject::Classname method for determining classes , note that the r->metaobject->className() pointer was also used when declaring type of registration hence it points first to registration then its children Guest and Student registrations 

I have added a qdebug function that shows each list of registration made via inputdialog-conferenceview connection so that each registration listed can be viewed . Please note this project is beta it will be improved gradually. 

For Question 2 and Question 3 , I have not added a file path to my file dialog as this is per user requirements , some want it via file explorer some on a disc , hence when running question 3 by default it will not display a file for xml I have built this as version1 as I learn more software design principles this application will be improved

As a novice developer I have taken all measures to deliver a user friendly project and user feed back is encouraged 

All documentation on code have been documented 
Thank you Mr Mhlana and team 😊

